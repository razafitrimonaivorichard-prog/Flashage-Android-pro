package mg.flashage.android

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private var malagasy = true
    private lateinit var body: LinearLayout
    private val usbAction = "mg.flashage.android.USB_PERMISSION"
    private val prefs by lazy { getSharedPreferences("flashage_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        registerUsbReceiver()
    }

    override fun onDestroy() {
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == usbAction) {
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                if (granted && device != null) showDeviceDetails(device)
                else show(tr("Tsy nahazo alalana USB.", "Autorisation USB refusée."))
            }
        }
    }

    private fun registerUsbReceiver() {
        val filter = IntentFilter(usbAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(usbReceiver, filter)
    }

    private fun tr(mg: String, fr: String) = if (malagasy) mg else fr

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(245, 248, 246))
        }
        root.addView(TextView(this).apply {
            text = "🤖 FLASHAGE ANDROID PRO"
            textSize = 24f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(30, 135, 70)); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = tr("Version 0.3 • Fanamarinana sy diagnostic", "Version 0.3 • Identification et diagnostic")
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
        })
        root.addView(Button(this).apply {
            text = tr("Malagasy / Français • Hanova fiteny", "Français / Malagasy • Changer la langue")
            setOnClickListener { malagasy = !malagasy; render() }
        })

        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        card("🔌 USB OTG", tr("Mitadiava fitaovana USB mifandray ary vakio ny anarana omen'ilay fitaovana rehefa nahazo alalana.",
            "Détecter les périphériques USB et lire leurs noms après autorisation."),
            tr("Hijery / Identifier USB", "Scanner / Identifier USB")) { scanUsb() }

        card("📝 " + tr("Ampidiro ny modèle", "Saisir le modèle"),
            tr("Raha tsy vakin'ny USB ny modèle dia soraty eto ny marque sy modèle exact.",
                "Si l'USB ne fournit pas le modèle, saisissez ici la marque et le modèle exacts."),
            tr("Ampiditra modèle", "Saisir le modèle")) { enterModel() }

        card("📱 " + tr("Fahalalana ity téléphone ity", "Informations de cet appareil"),
            "${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE}",
            tr("Antsipiriany", "Détails")) {
            show("Fabricant: ${Build.MANUFACTURER}\nModèle: ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE}\nSDK: ${Build.VERSION.SDK_INT}")
        }

        card("🧩 " + tr("Fanamarinana Firmware", "Vérification du firmware"),
            tr("Jereo ny modèle exact, codename, région, build ary chipset alohan'ny hampiasana firmware.",
                "Vérifiez le modèle exact, codename, région, build et chipset avant d'utiliser un firmware."),
            tr("Lisitra fanamarinana", "Liste de contrôle")) { firmwareChecklist() }

        card("⬇️ Firmware / ROM",
            tr("Ampiasao loharano ofisialy sy firmware mifanaraka amin'ny modèle exact.",
                "Utilisez une source officielle et un firmware correspondant exactement au modèle."),
            tr("Fampitandremana", "Précautions")) {
            show(tr("Tsy mbola misy téléchargement automatique amin'ity version ity. Aza mampiasa firmware avy amin'ny modèle hafa: mety hanimba ny téléphone.",
                "Le téléchargement automatique n'est pas encore disponible dans cette version. N'utilisez jamais le firmware d'un autre modèle : cela peut endommager l'appareil."))
        }

        card("⚙️ Flashage / ADB / Fastboot",
            tr("Fampahalalana momba ny fepetra sy protocoles ilaina.", "Informations sur les prérequis et protocoles nécessaires."),
            tr("Jereo", "Consulter")) {
            show(tr("USB OTG irery tsy manome fahafahana hanao flashage universel. Miankina amin'ny bootloader, chipset, protocole ary outil ofisialin'ny marque ny asa. Mety mbola mila PC.",
                "L'USB OTG seul ne permet pas un flashage universel. Cela dépend du bootloader, du chipset, du protocole et des outils du fabricant. Un PC peut rester nécessaire."))
        }

        card("♻️ Restauration / 🛟 Recovery",
            tr("Torolalana momba ny backup, factory reset ary fiarovana données.",
                "Guides de sauvegarde, réinitialisation d'usine et protection des données."),
            tr("Vakio", "Lire")) {
            show(tr("Ataovy backup aloha. Factory reset mamafa données. Ho an'ny récupération, ajanony ny fampiasana raha very fichiers; tsy azo antoka ny récupération amin'ny Android voaaro encryption.",
                "Faites une sauvegarde. La réinitialisation efface les données. Après une perte de fichiers, cessez d'utiliser l'appareil; la récupération n'est pas garantie sur Android chiffré."))
        }

        val saved = prefs.getString("saved_model", null)
        if (!saved.isNullOrBlank()) {
            card("📌 " + tr("Modèle voatahiry", "Modèle enregistré"), saved,
                tr("Ovaina", "Modifier")) { enterModel() }
        }

        setContentView(root)
    }

    private fun card(title: String, description: String, button: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 13, 15, 13); setBackgroundColor(Color.WHITE)
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 18f; setTextColor(Color.rgb(28, 105, 58))
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply {
            text = description; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, 7, 0, 5)
        })
        box.addView(Button(this).apply { text = button; setOnClickListener { action() } })
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }

    private fun scanUsb() {
        val manager = getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = manager.deviceList.values.toList()
        if (devices.isEmpty()) {
            show(tr("Tsy misy fitaovana hita. Hamarino ny câble OTG sy ny USB host.", 
                "Aucun périphérique détecté. Vérifiez le câble OTG et la fonction USB host."))
            return
        }
        val options = devices.map { d ->
            "${brandFromVid(d.vendorId)} — VID ${d.vendorId.toString(16).uppercase()} / PID ${d.productId.toString(16).uppercase()} — ${d.deviceName}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(tr("Fitaovana USB hita", "Périphériques USB détectés"))
            .setItems(options) { _, which -> requestUsbPermission(manager, devices[which]) }
            .setNegativeButton(tr("Hidio", "Fermer"), null).show()
    }

    private fun brandFromVid(vid: Int): String = when (vid) {
        0x04E8 -> "Samsung (VID connu)"
        0x12D1 -> "Huawei (VID connu)"
        0x2717 -> "Xiaomi (VID connu)"
        0x22B8 -> "Motorola (VID connu)"
        0x22D9 -> "OPPO (VID connu)"
        else -> tr("Marque tsy fantatra amin'ny VID", "Marque non identifiée par VID")
    }

    private fun requestUsbPermission(manager: UsbManager, device: UsbDevice) {
        val intent = Intent(usbAction).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pending = PendingIntent.getBroadcast(this, device.deviceId, intent, flags)
        manager.requestPermission(device, pending)
    }

    private fun showDeviceDetails(device: UsbDevice) {
        val manager = getSystemService(Context.USB_SERVICE) as UsbManager
        val manufacturer = try { device.manufacturerName ?: "—" } catch (_: Exception) { "—" }
        val product = try { device.productName ?: "—" } catch (_: Exception) { "—" }
        val serial = try { device.serialNumber ?: "—" } catch (_: Exception) { "—" }
        val info = "USB manufacturer: $manufacturer\nUSB product: $product\nSerial: $serial\nVID: ${device.vendorId}\nPID: ${device.productId}\nInterfaces: ${device.interfaceCount}\nUSB permission: ${manager.hasPermission(device)}\n\n" +
            tr("Fanamarihana: mety tsy hanome ny tena modèle Android ny USB. Ampidiro tanana raha ilaina.",
               "Note : l'USB ne fournit pas toujours le modèle Android exact. Saisissez-le manuellement si nécessaire.")
        show(info)
    }

    private fun enterModel() {
        val input = EditText(this).apply {
            hint = tr("Ohatra: Samsung SM-A145F", "Exemple : Samsung SM-A145F")
            setText(prefs.getString("saved_model", ""))
        }
        AlertDialog.Builder(this).setTitle(tr("Marque sy modèle exact", "Marque et modèle exact"))
            .setView(input)
            .setPositiveButton(tr("Tehirizo", "Enregistrer")) { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    prefs.edit().putString("saved_model", value).apply()
                    show(tr("Voatahiry: $value", "Enregistré : $value"))
                    render()
                }
            }.setNegativeButton(tr("Aoka", "Annuler"), null).show()
    }

    private fun firmwareChecklist() {
        show(tr(
            "Alohan'ny firmware:\n1. Model number marina.\n2. Codename sy chipset.\n3. Région/CSC sy build.\n4. Batterie 60%+.\n5. Backup natao.\n6. Firmware ofisialy sy signature voamarina.\n\nAza flash raha misy tsy mifanaraka.",
            "Avant le firmware :\n1. Numéro de modèle exact.\n2. Codename et chipset.\n3. Région/CSC et build.\n4. Batterie supérieure à 60 %.\n5. Sauvegarde effectuée.\n6. Firmware officiel et signature vérifiée.\n\nNe flashez pas en cas d'incompatibilité."
        ))
    }

    private fun show(message: String) {
        AlertDialog.Builder(this).setTitle("FLASHAGE ANDROID PRO")
            .setMessage(message).setPositiveButton("OK", null).show()
    }
}
