FLASHAGE ANDROID PRO — Version source 0.3.0

NOUVEAUTÉS
- Liste des périphériques USB détectés.
- Estimation de marque à partir de certains Vendor ID USB connus (indicatif seulement).
- Demande d'autorisation USB puis lecture des descripteurs fabricant/produit/numéro de série si Android les expose.
- Saisie et sauvegarde locale du modèle exact.
- Liste de contrôle de compatibilité firmware.

FETRA / LIMITES
Ny Vendor ID dia famantarana fanampiny fa tsy manaporofo ny modèle. Mety tsy hiseho amin'ny USB OTG ny tena modèle na serial.
Le Vendor ID n'est qu'un indice et ne prouve pas le modèle exact. Le modèle ou le numéro de série peut ne pas être exposé en USB OTG.

Ity version ity dia tsy manao flashage, déverrouillage bootloader, contournement FRP, récupération réelle de données, na téléchargement automatique de firmware.
Cette version n'effectue pas de flashage, déverrouillage du bootloader, contournement FRP, récupération réelle de données ni téléchargement automatique de firmware.

CONSTRUIRE L'APK
1. Installer Android Studio.
2. Ouvrir ce dossier comme projet.
3. Installer Android SDK Platform 35.
4. Synchroniser Gradle.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK : app/build/outputs/apk/debug/app-debug.apk

Minimum Android : 8.0 (API 26). Version projet : 0.3.0.


FANAMBOARANA APK AMIN'NY GITHUB ACTIONS
1. Mamoròna repository GitHub vaovao.
2. Ampidiro ao ny votoatin'ity ZIP ity (ao anatin'izany ny dossier .github).
3. Sokafy ny tabilao Actions.
4. Alefaso ny workflow "Build Android APK" (Run workflow).
5. Rehefa vita, sokafy ny run farany ary alaivo ny artifact "FlashageAndroid-debug-apk".
6. Esory (extract) ilay artifact ZIP; ao anatiny ny app-debug.apk.

Remarque : l'environnement de cette conversation ne dispose pas de Gradle ni du SDK Android pour compiler et tester le binaire APK directement. Le workflow GitHub ci-dessus compile le projet et publie l'APK comme artifact.
